from chatterbot import ChatBot
from chatterbot.trainers import ChatterBotCorpusTrainer

# Crear una instancia del chatbot
chatbot = ChatBot('Mi Chatbot', logic_adapters=[
    {
        'import_path': 'chatterbot.logic.BestMatch',
        'default_response': '¡Vaya! Parece que estoy fuera de servicio en este momento. ¿Podrías intentarlo más tarde?',
        'maximum_similarity_threshold': 0.90
    }
])

# Crear un entrenador para el chatbot
trainer = ChatterBotCorpusTrainer(chatbot)

# Entrenar el chatbot con el corpus de datos en inglés
trainer.train('chatterbot.corpus.english')

# Función para obtener una respuesta sarcástica del chatbot
def obtener_respuesta(mensaje):
    respuesta = chatbot.get_response(mensaje)
    return respuesta.text if respuesta.confidence > 0.5 else "Oh, por favor, dime algo interesante."

# Loop principal del chatbot
while True:
    entrada = input("Tú: ")
    if entrada.lower() == 'adiós':
        break
    respuesta = obtener_respuesta(entrada)
    print("Chatbot:", respuesta)
